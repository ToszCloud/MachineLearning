# -- coding: utf-8 --
"""
Created on Thu May 14 17:20:41 2020

@author: oookr
"""

import numpy as np
#import matplotlib.pyplot as plt
#import random
import pandas as pd

data=pd.read_csv('iris.data')
data_use = data.iloc[:,0:5].values
k = int(input('give the number of cluster you want to have   '))

# use k points from the data as the centrod for starting 
centers_use = data.iloc[0:k,:4].values.tolist()

"""
define a function to calculate the euclidian distance between each data point 

and the centriod and assign the data point to the nearest centroid
"""
def point_clustering(data, centers, dims):
    for point in data:
        nearest_center = 0
        nearest_center_dist = None
        for i in range(0, len(centers)):
            euclidean_dist = 0
            for d in range(0, dims):
                dist = (point[d] - centers[i][d])**2
                euclidean_dist += dist
            euclidean_dist = np.sqrt(euclidean_dist)
            #print('distance ', euclidean_dist)
            if nearest_center_dist == None:
                nearest_center_dist = euclidean_dist
                nearest_center = i
            elif nearest_center_dist > euclidean_dist:
                nearest_center_dist = euclidean_dist
                nearest_center = i
            point[-1] = nearest_center
    return data

"""
define a function to calculate a mean of the all the data points assigned toa particular 
centroid and calculate the mean so that we can have a new centriod to do the distance 
calculation and can assign the data points to a new cluster(centroid)
"""

def mean_center(data, centers, dims):
    for i in range(len(centers)):
        new_center = []
        n_of_points = 0
        total_of_points = []
        for point in data:
            if point[-1] == i:
                n_of_points += 1
                for dim in range(0,dims):
                    if dim < len(total_of_points):
                        total_of_points[dim] += point[dim]
                    else:
                        total_of_points.append(point[dim])
        if len(total_of_points) != 0:
            for dim in range(0,dims):
                new_center.append(total_of_points[dim]/n_of_points)
            centers_use[i]= new_center
        else:
            centers_use[i]= centers[i]




# assign the data points to the centroids and change it 10 times for better assignment
for i in range(10):
    
    data_after = pd.DataFrame(point_clustering(data_use,centers_use , k))

    # need to go to all the clusters k
    for cluster in range(k):
        euclidean_dist = 0
        # calculate all euclidian distance of each cluster and save it in one list
        list_of_euc_dist = []
        # get  all the points with same cluster
        for j in range(data_after.loc[data_after[4]==cluster].shape[0]):
            #calculate the euclidian distance
                for d in range(0, k):
                    dist = (data_after.loc[data_after[4]==cluster].values[j][d] - centers_use[cluster][d])**2
                    euclidean_dist += dist
                euclidean_dist = np.sqrt(euclidean_dist)
                list_of_euc_dist.append(euclidean_dist)
        
        print('mean distance of the',cluster+1,'cluster is::  ',np.mean(list_of_euc_dist))
    print('#######')
    mean_center(data_use, centers_use,k)

# print member of each cluster
Final_data = pd.DataFrame(data_use)
print('member of  first cluster :   \n',Final_data.loc[Final_data[4]==0].values)
print('member of  second cluster :   \n',Final_data.loc[Final_data[4]==1].values)
print('member of  third cluster :   \n',Final_data.loc[Final_data[4]==2].values)


# yo chai kind of wrong 6 hai 

print('Iris-setosa : ',(Final_data.loc[Final_data[4]==1].values.shape[0])*100/104,' %')
print('Iris-versicolor : ',(Final_data.loc[Final_data[4]==2].values.shape[0])*100/104,' %')
print('Iris-virginica : ',(Final_data.loc[Final_data[4]==0].values.shape[0])*100/104,' %')